﻿RS Mapper 0.46b

Disclaimer:
This product ships "AS IS", with no warranties at all.
Distribution: only as freeware product, with no changes to code and resources.

This software was written using C# language and Microsoft .NET platform. Currently requires .NET Framework 4.6 but if that's a problem just let me know, I can lower the requirement.
Interaction with DirecX/Direct Input occurs trough the SharpDX library (copyright and permission at the bottom of this file).

Primary reason for creation of this application was to overcome serious limitations of the SV Mapper software, namely:
 - SV Mapper was unable to utilize more than 4 devices (and if you did have more, they could appear at random in the software GUI)
 - You could not easily transfer saved profiles between computers, even if the devices were the same (GUID differences)

 These two issues no longer appear in RS Mapper.

 Basics of operations: RS Mapper allows you to map keyboard presses to be sent when you trigger your device buttons and POVs. 
 You can trigger keyboard keys for simple press, long (over 1s, like in A-10C controls) press and on button release. This effectively gives you two events 
 for single-throw toggle-switches found in Thrustmaster Hotas or MJoy devices.
 By using RS Mapper you are also able to program series of repetitions of the key presses, or even map continuous press (helpful for Push-to-talk).

Many thanks to Grooz for inspiration and testing. Also big thanks to the rest of testers/early adopters crew: Springman, Ali, Czart and Dave

Copyright (c) 2018 
Rafal Szul
rafal.szul@gmail.com

VERSION HISTORY
0.45: Defect fixes and additional keys
	- Fixed a defect when some extended keys (like numpad enter) would substitute regular version upon re-opening action dialog.
	- Added left windows key to supported actions
	- Added pause key to supported actions
0.44: Long press gains "continous" option
	- You can now set long-press action to fire on continous basis
0.43: Single press no longer fire together with longpress
	- When you map both single press and long press button actions single press action will only fire if you release button before full 1s of longpress timer expire.
0.42: Bug fix
	- Fixed defect when on some keyboards "[" and "]" where switched.
0.41: Minor bug fix
	- Fixed error occurring when re-opening action dialog while only change profile action was defined.
0.40: Minor bug fixes
	- Added support for right and left backslash ("\ |") key.
0.39: Bug fixes
	- Number of bugs related to continous press on POV has been solved
0.38: Bug fixes and profiles
	- RS Mapper now features option to change between profiles on button/POV press. This means you can create "pinky switch" behaviour that completely remaps your keystrokes as long you have a button (or mode switch) toggled.
	- Fixed bug with incorrect sequence of key / modifier release.
0.37: Bug fixes
	- Fixed problem with continous events and right modifier keys
0.36 : Minor bug fix
	- Fixed defect with all profiles being marked as active while using autoload feature.
0.35 : Profiles come to RS Mapper
	- Introducing a concept of a "Profile" - it is a set of all mapped actions for selected devices. 
	Starting from version 0.35 you are able to add more than one profile (menu "Profiles -> New profile") and switch between them by clicking profile name in the Profile menu.
	Currently selected profile will be marked by a "tick" on the menu and it's name will be shown in the status bar (bottom of the window). 
	This feature enables you to store key mappings for multiple games in one file.
	- Added option to import previously saved files. Choose "Import" option from the File menu to add profiles saved in the selected file to your current mappings.
	This feature enables you to merge couple of files into one. Remember to save the new mapping file after importing!
	- Only once instance of RS Mapper can run at a time.
	- Refurbished "About" window. Now readme.txt file is also shown there.
0.32 trough 0.34: closed developer versions
0.31: Minor bug fix
	- "All mapped actions" list did not properly distinguished between left/right and numpad keys. The bug was display only 
	(that is: proper key was being sent even though wrong name was displayed on the list). This issue has been addressed now.
0.30: Original Release

------------
Original SharpDX licence below (this apply to SharpDX only, not to RS Mapper as a whole)

Copyright (c) 2010-2014 SharpDX - Alexandre Mutel

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.